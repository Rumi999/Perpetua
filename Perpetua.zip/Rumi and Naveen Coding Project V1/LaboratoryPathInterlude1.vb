﻿Public Class LaboratoryPathInterlude1
    Public labPath As Boolean = False
    Private Sub LaboratoryPathInterlude1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MyBase.KeyPress
        If Asc(e.KeyChar) = 32 Then
            labPath = True
            PerpetuaMain.Show()
            PerpetuaMain.firstTile = PerpetuaMain.bmpIndustrialFloor

            Me.Close()
        End If
    End Sub

    Private Sub LaboratoryPathInterlude1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class