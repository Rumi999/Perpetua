﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class TilesAndCharacter
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.picScientist = New System.Windows.Forms.PictureBox()
        Me.picSign = New System.Windows.Forms.PictureBox()
        Me.picAxe = New System.Windows.Forms.PictureBox()
        Me.picFire = New System.Windows.Forms.PictureBox()
        Me.picBrick = New System.Windows.Forms.PictureBox()
        Me.picTable = New System.Windows.Forms.PictureBox()
        Me.picTipi = New System.Windows.Forms.PictureBox()
        Me.picHole = New System.Windows.Forms.PictureBox()
        Me.picPickaxe = New System.Windows.Forms.PictureBox()
        Me.picBoulder = New System.Windows.Forms.PictureBox()
        Me.picLogItem = New System.Windows.Forms.PictureBox()
        Me.picRockItem = New System.Windows.Forms.PictureBox()
        Me.picRock = New System.Windows.Forms.PictureBox()
        Me.wolfSprite = New System.Windows.Forms.PictureBox()
        Me.picDirt = New System.Windows.Forms.PictureBox()
        Me.picTree = New System.Windows.Forms.PictureBox()
        Me.picIndustrialFloor = New System.Windows.Forms.PictureBox()
        Me.picSprite2 = New System.Windows.Forms.PictureBox()
        Me.picWater = New System.Windows.Forms.PictureBox()
        Me.picGrass = New System.Windows.Forms.PictureBox()
        CType(Me.picScientist, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSign, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAxe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFire, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBrick, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTable, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTipi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picHole, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPickaxe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBoulder, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLogItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRockItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRock, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.wolfSprite, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDirt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTree, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picIndustrialFloor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSprite2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWater, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picGrass, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picScientist
        '
        Me.picScientist.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.TheScientist
        Me.picScientist.Location = New System.Drawing.Point(238, 334)
        Me.picScientist.Name = "picScientist"
        Me.picScientist.Size = New System.Drawing.Size(37, 38)
        Me.picScientist.TabIndex = 19
        Me.picScientist.TabStop = False
        '
        'picSign
        '
        Me.picSign.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.grassTexture___Sign
        Me.picSign.Location = New System.Drawing.Point(295, 52)
        Me.picSign.Name = "picSign"
        Me.picSign.Size = New System.Drawing.Size(40, 48)
        Me.picSign.TabIndex = 18
        Me.picSign.TabStop = False
        '
        'picAxe
        '
        Me.picAxe.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.grassTexture___Axe
        Me.picAxe.Location = New System.Drawing.Point(362, 295)
        Me.picAxe.Name = "picAxe"
        Me.picAxe.Size = New System.Drawing.Size(50, 33)
        Me.picAxe.TabIndex = 17
        Me.picAxe.TabStop = False
        '
        'picFire
        '
        Me.picFire.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.fire
        Me.picFire.Location = New System.Drawing.Point(235, 52)
        Me.picFire.Name = "picFire"
        Me.picFire.Size = New System.Drawing.Size(47, 50)
        Me.picFire.TabIndex = 16
        Me.picFire.TabStop = False
        '
        'picBrick
        '
        Me.picBrick.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.Brick
        Me.picBrick.Location = New System.Drawing.Point(181, 52)
        Me.picBrick.Name = "picBrick"
        Me.picBrick.Size = New System.Drawing.Size(44, 37)
        Me.picBrick.TabIndex = 15
        Me.picBrick.TabStop = False
        '
        'picTable
        '
        Me.picTable.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.GoodIndustrialFloor___Table
        Me.picTable.Location = New System.Drawing.Point(134, 52)
        Me.picTable.Name = "picTable"
        Me.picTable.Size = New System.Drawing.Size(41, 34)
        Me.picTable.TabIndex = 14
        Me.picTable.TabStop = False
        '
        'picTipi
        '
        Me.picTipi.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.Teepee
        Me.picTipi.Location = New System.Drawing.Point(74, 52)
        Me.picTipi.Name = "picTipi"
        Me.picTipi.Size = New System.Drawing.Size(31, 34)
        Me.picTipi.TabIndex = 13
        Me.picTipi.TabStop = False
        '
        'picHole
        '
        Me.picHole.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.grassTexture_Hole
        Me.picHole.Location = New System.Drawing.Point(12, 52)
        Me.picHole.Name = "picHole"
        Me.picHole.Size = New System.Drawing.Size(47, 48)
        Me.picHole.TabIndex = 12
        Me.picHole.TabStop = False
        '
        'picPickaxe
        '
        Me.picPickaxe.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.pickaxeTexture
        Me.picPickaxe.Location = New System.Drawing.Point(320, 295)
        Me.picPickaxe.Name = "picPickaxe"
        Me.picPickaxe.Size = New System.Drawing.Size(36, 32)
        Me.picPickaxe.TabIndex = 11
        Me.picPickaxe.TabStop = False
        '
        'picBoulder
        '
        Me.picBoulder.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.BoulderTexture
        Me.picBoulder.Location = New System.Drawing.Point(341, 12)
        Me.picBoulder.Name = "picBoulder"
        Me.picBoulder.Size = New System.Drawing.Size(54, 34)
        Me.picBoulder.TabIndex = 10
        Me.picBoulder.TabStop = False
        '
        'picLogItem
        '
        Me.picLogItem.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.grassTexture_Log_Hole
        Me.picLogItem.Location = New System.Drawing.Point(281, 294)
        Me.picLogItem.Name = "picLogItem"
        Me.picLogItem.Size = New System.Drawing.Size(37, 34)
        Me.picLogItem.TabIndex = 9
        Me.picLogItem.TabStop = False
        '
        'picRockItem
        '
        Me.picRockItem.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.RockOnGrassTexture
        Me.picRockItem.Location = New System.Drawing.Point(240, 294)
        Me.picRockItem.Name = "picRockItem"
        Me.picRockItem.Size = New System.Drawing.Size(35, 34)
        Me.picRockItem.TabIndex = 8
        Me.picRockItem.TabStop = False
        '
        'picRock
        '
        Me.picRock.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.rockTexture
        Me.picRock.Location = New System.Drawing.Point(281, 12)
        Me.picRock.Name = "picRock"
        Me.picRock.Size = New System.Drawing.Size(54, 34)
        Me.picRock.TabIndex = 7
        Me.picRock.TabStop = False
        '
        'wolfSprite
        '
        Me.wolfSprite.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.WolfSpriteSheet
        Me.wolfSprite.Location = New System.Drawing.Point(144, 294)
        Me.wolfSprite.Name = "wolfSprite"
        Me.wolfSprite.Size = New System.Drawing.Size(64, 96)
        Me.wolfSprite.TabIndex = 6
        Me.wolfSprite.TabStop = False
        '
        'picDirt
        '
        Me.picDirt.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.TextureThatIsDirt
        Me.picDirt.Location = New System.Drawing.Point(240, 12)
        Me.picDirt.Name = "picDirt"
        Me.picDirt.Size = New System.Drawing.Size(35, 34)
        Me.picDirt.TabIndex = 5
        Me.picDirt.TabStop = False
        '
        'picTree
        '
        Me.picTree.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.Tree
        Me.picTree.Location = New System.Drawing.Point(181, 12)
        Me.picTree.Name = "picTree"
        Me.picTree.Size = New System.Drawing.Size(44, 34)
        Me.picTree.TabIndex = 4
        Me.picTree.TabStop = False
        '
        'picIndustrialFloor
        '
        Me.picIndustrialFloor.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.GoodIndustrialFloor
        Me.picIndustrialFloor.Location = New System.Drawing.Point(134, 12)
        Me.picIndustrialFloor.Name = "picIndustrialFloor"
        Me.picIndustrialFloor.Size = New System.Drawing.Size(41, 34)
        Me.picIndustrialFloor.TabIndex = 3
        Me.picIndustrialFloor.TabStop = False
        '
        'picSprite2
        '
        Me.picSprite2.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.AbsolouteFinalCharacter1
        Me.picSprite2.Location = New System.Drawing.Point(12, 294)
        Me.picSprite2.Name = "picSprite2"
        Me.picSprite2.Size = New System.Drawing.Size(102, 144)
        Me.picSprite2.TabIndex = 2
        Me.picSprite2.TabStop = False
        '
        'picWater
        '
        Me.picWater.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.waterTexture
        Me.picWater.Location = New System.Drawing.Point(74, 12)
        Me.picWater.Name = "picWater"
        Me.picWater.Size = New System.Drawing.Size(40, 34)
        Me.picWater.TabIndex = 1
        Me.picWater.TabStop = False
        '
        'picGrass
        '
        Me.picGrass.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.grassTexture
        Me.picGrass.Location = New System.Drawing.Point(12, 12)
        Me.picGrass.Name = "picGrass"
        Me.picGrass.Size = New System.Drawing.Size(41, 34)
        Me.picGrass.TabIndex = 0
        Me.picGrass.TabStop = False
        '
        'TilesAndCharacter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(450, 450)
        Me.Controls.Add(Me.picScientist)
        Me.Controls.Add(Me.picSign)
        Me.Controls.Add(Me.picAxe)
        Me.Controls.Add(Me.picFire)
        Me.Controls.Add(Me.picBrick)
        Me.Controls.Add(Me.picTable)
        Me.Controls.Add(Me.picTipi)
        Me.Controls.Add(Me.picHole)
        Me.Controls.Add(Me.picPickaxe)
        Me.Controls.Add(Me.picBoulder)
        Me.Controls.Add(Me.picLogItem)
        Me.Controls.Add(Me.picRockItem)
        Me.Controls.Add(Me.picRock)
        Me.Controls.Add(Me.wolfSprite)
        Me.Controls.Add(Me.picDirt)
        Me.Controls.Add(Me.picTree)
        Me.Controls.Add(Me.picIndustrialFloor)
        Me.Controls.Add(Me.picSprite2)
        Me.Controls.Add(Me.picWater)
        Me.Controls.Add(Me.picGrass)
        Me.Name = "TilesAndCharacter"
        Me.Text = "TilesAndCharacter"
        CType(Me.picScientist, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSign, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAxe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFire, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBrick, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTable, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTipi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picHole, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPickaxe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBoulder, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLogItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRockItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRock, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.wolfSprite, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDirt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTree, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picIndustrialFloor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSprite2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWater, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picGrass, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents picGrass As PictureBox
    Friend WithEvents picWater As PictureBox
    Friend WithEvents picSprite2 As PictureBox
    Friend WithEvents picIndustrialFloor As PictureBox
    Friend WithEvents picTree As PictureBox
    Friend WithEvents picDirt As PictureBox
    Friend WithEvents wolfSprite As PictureBox
    Friend WithEvents picRock As PictureBox
    Friend WithEvents picRockItem As PictureBox
    Friend WithEvents picLogItem As PictureBox
    Friend WithEvents picBoulder As PictureBox
    Friend WithEvents picPickaxe As PictureBox
    Friend WithEvents picHole As PictureBox
    Friend WithEvents picTipi As PictureBox
    Friend WithEvents picTable As PictureBox
    Friend WithEvents picBrick As PictureBox
    Friend WithEvents picFire As PictureBox
    Friend WithEvents picAxe As PictureBox
    Friend WithEvents picSign As PictureBox
    Friend WithEvents picScientist As PictureBox
End Class
