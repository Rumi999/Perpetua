﻿Public Class LeftTunnelPath1
    Public FollowThePath As Boolean
    Public TheLakePath As Boolean
    Public TheClearingPath As Boolean = False


    Private Sub lblFollowThePath_Click(sender As Object, e As EventArgs) Handles lblFollowThePath.Click
        TheClearingPath = False
        TheLakePath = False
        FollowThePath = True
        PerpetuaMain.Show()
        PerpetuaMain.firstTile = PerpetuaMain.bmpDirt
        Me.Close()
    End Sub

    Private Sub lblHeadToTheClearing_Click(sender As Object, e As EventArgs) Handles lblHeadToTheClearing.Click
        FollowThePath = False
        TheLakePath = False
        TheClearingPath = True
        PerpetuaMain.Show()
        PerpetuaMain.firstTile = PerpetuaMain.bmpDirt
        Me.Close()
    End Sub

    Private Sub lblTowardsTheLake_Click(sender As Object, e As EventArgs) Handles lblTowardsTheLake.Click
        TheClearingPath = False
        FollowThePath = False
        TheLakePath = True
        PerpetuaMain.Show()
        PerpetuaMain.firstTile = PerpetuaMain.bmpDirt
        Me.Close()
    End Sub

    Private Sub LeftTunnelPath1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class