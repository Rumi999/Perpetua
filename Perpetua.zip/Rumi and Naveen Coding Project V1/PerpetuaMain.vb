﻿Public Class PerpetuaMain

    Dim backbuffer As Bitmap
    Dim miniBuffer As Bitmap
    'Textures
    Dim bmpCharacter As Bitmap
    Public bmpGrass As Bitmap
    Public bmpBoulder As Bitmap
    Public bmpWater As Bitmap
    Public bmpIndustrialFloor As Bitmap
    Public bmpTree As Bitmap
    Public bmpDirt As Bitmap
    Public bmpWolf As Bitmap
    Public bmpRock As Bitmap
    Public bmpHole As Bitmap
    Public bmpTipi As Bitmap
    Public bmpBrick As Bitmap
    Public bmpTable As Bitmap
    Public bmpFirePit As Bitmap




    'Pickupable items
    Public bmpItemRock As Bitmap
    Public bmpItemPickaxe As Bitmap
    Public bmpItemLog As Bitmap
    Public bmpItemAxe As Bitmap


    'Event Bitmaps
    Public bmpSign As Bitmap
    Public bmpScientist As Bitmap

    'Bitmap for first tile loading :)
    Public firstTile As Bitmap

    'LoadingDoors
    Dim lmDoor As Boolean = True
    Dim level101HiddenPath As Boolean = False

    Dim savedX As Integer
    Dim savedY As Integer

    Dim challengeExit As Boolean
    Dim boulderChallengeCompleted As Boolean = False
    Dim firstLoad As Boolean = True
    Public firstTreeRun = True
    Public level As Decimal
    Dim tilesize As Integer = 32
    Dim firstSource As Rectangle
    Dim rectSource As Rectangle
    Dim rect0 As Rectangle
    Dim startRect As Rectangle
    Dim rectDest As Rectangle
    Dim curx As Integer, cury As Integer
    Dim line As String
    Dim mapLoader(14, 14) As String
    Dim row() As String

    'Moving Tree
    Dim oldTreeCurX As Integer
    Dim treeCurX As Integer
    Dim treeRectSource As Rectangle
    Dim oldTreeRectSource As Rectangle = New Rectangle(224, 224, tilesize, tilesize)

    Dim streamReader As System.IO.StreamReader

    Enum dir As Integer
        down = 0
        left = 1
        right = 2
        up = 3
    End Enum
    Dim direction As dir
    Dim lastDirection As dir

    Dim moves As Integer
    Dim smallMove As Double = 10    'character makes 3 small moves for each key press

    Private Sub MainGame(ByVal level As Decimal)
        Dim g As Graphics
        Dim gmini As Graphics


        'set up all graphics objects into virtual bitmaps
        backbuffer = New Bitmap(Me.ClientRectangle.Width, Me.ClientRectangle.Height)
        miniBuffer = New Bitmap(tilesize, tilesize)
        bmpCharacter = New Bitmap(TilesAndCharacter.picSprite2.Image, 98, 128)
        bmpCharacter.MakeTransparent(Color.White)
        bmpWolf = New Bitmap(TilesAndCharacter.wolfSprite.Image)
        bmpGrass = New Bitmap(TilesAndCharacter.picGrass.Image, tilesize, tilesize)
        bmpWater = New Bitmap(TilesAndCharacter.picWater.Image, tilesize, tilesize)
        bmpIndustrialFloor = New Bitmap(TilesAndCharacter.picIndustrialFloor.Image, tilesize, tilesize)
        bmpTree = New Bitmap(TilesAndCharacter.picTree.Image, tilesize, tilesize)
        bmpDirt = New Bitmap(TilesAndCharacter.picDirt.Image, tilesize, tilesize)
        bmpRock = New Bitmap(TilesAndCharacter.picRock.Image, tilesize, tilesize)
        bmpHole = New Bitmap(TilesAndCharacter.picHole.Image, tilesize, tilesize)
        bmpBoulder = New Bitmap(TilesAndCharacter.picBoulder.Image, tilesize, tilesize)
        bmpTipi = New Bitmap(TilesAndCharacter.picTipi.Image, tilesize, tilesize)
        bmpBrick = New Bitmap(TilesAndCharacter.picBrick.Image, tilesize, tilesize)
        bmpTable = New Bitmap(TilesAndCharacter.picTable.Image, tilesize, tilesize)
        bmpFirePit = New Bitmap(TilesAndCharacter.picFire.Image, tilesize, tilesize)


        'Item Textures 
        bmpItemRock = New Bitmap(TilesAndCharacter.picRockItem.Image, tilesize, tilesize)
        bmpItemLog = New Bitmap(TilesAndCharacter.picLogItem.Image, tilesize, tilesize)
        bmpItemPickaxe = New Bitmap(TilesAndCharacter.picPickaxe.Image, tilesize, tilesize)
        bmpItemAxe = New Bitmap(TilesAndCharacter.picAxe.Image, tilesize, tilesize)

        'Event Textures
        bmpSign = New Bitmap(TilesAndCharacter.picSign.Image, tilesize, tilesize)
        bmpScientist = New Bitmap(TilesAndCharacter.picScientist.Image, tilesize, tilesize)


        'set all original rectangles to location 0,0
        rectSource = New Rectangle(32, 0, tilesize, tilesize)
        rect0 = New Rectangle(0, 0, tilesize, tilesize)
        startRect = New Rectangle(32, 0, tilesize, tilesize)
        rectDest = New Rectangle(0, 0, tilesize, tilesize)

        'tie g to the backBuffer and gmini to the miniBuffer
        g = Graphics.FromImage(backbuffer)
        gmini = Graphics.FromImage(miniBuffer)

        'fill in the background with a default map  (will be all 0's so all grass)
        'later you can load the map from a file

        Try
            If level = 100 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\FollowThePath0.txt")
            ElseIf level = 101 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\FollowThePath1.txt")
            ElseIf level = 102 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\FollowThePath2.txt")
            ElseIf level = 102.5 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\FollowThePath2.5.txt")
            ElseIf level = 200 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\LakePath0.txt")
            ElseIf level = 201 Then
                'REMEMBER UNLOCKED
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\LakePath1Locked.txt")
            ElseIf level = 201.5 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\LakePath1Challenge.txt")
            ElseIf level = 202 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\LakePath2.txt")
            ElseIf level = 300 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\theclearingpath0.txt")
            ElseIf level = 301 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\theclearingpath1.txt")
            ElseIf level = 301.5 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\TheClearingPath1(RemovedLog).txt")
            ElseIf level = 400 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\LaboratoryPath0.txt")
            ElseIf level = 401 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\LaboratoryPath1.txt")
            ElseIf level = 401.5 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\LaboratoryPath1(NoScientist).txt")
            ElseIf level = 402 Then
                streamReader = My.Computer.FileSystem.OpenTextFileReader(Application.StartupPath & "\LaboratoryPath2.txt")
            End If

            Dim m As Integer = 0

            'THIS CODE HERE IS HOW THE TILES ARE LOADED IN, EACH TILE IS BASED OFF A NUMBER
            Do Until streamReader.EndOfStream
                line = streamReader.ReadLine
                row = line.Split(",")
                For n As Integer = 0 To 14
                    mapLoader(n, m) = row(n)
                    rectDest = New Rectangle(n * tilesize, m * tilesize, tilesize, tilesize)
                    If row(n) = 0 Then
                        g.DrawImage(bmpGrass, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 1 Then
                        g.DrawImage(bmpWater, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 2 Then
                        g.DrawImage(bmpIndustrialFloor, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 3 Then
                        g.DrawImage(bmpTree, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 4 Then
                        g.DrawImage(bmpDirt, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 5 Then
                        g.DrawImage(bmpRock, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 6 Then
                        g.DrawImage(bmpHole, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 7 Then
                        g.DrawImage(bmpTipi, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 8 Then
                        g.DrawImage(bmpBrick, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 9 Then
                        g.DrawImage(bmpTable, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 10 Then
                        g.DrawImage(bmpFirePit, rectDest, rect0, GraphicsUnit.Pixel)



                        'ITEM TEXTURES
                    ElseIf row(n) = 20 Then
                        g.DrawImage(bmpItemRock, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 21 Then
                        g.DrawImage(bmpItemLog, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 22 Then
                        g.DrawImage(bmpBoulder, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 23 Then
                        g.DrawImage(bmpItemPickaxe, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 24 Then
                        g.DrawImage(bmpItemAxe, rectDest, rect0, GraphicsUnit.Pixel)

                        'EVENT TEXTURES

                    ElseIf row(n) = 40 Then
                        g.DrawImage(bmpSign, rectDest, rect0, GraphicsUnit.Pixel)
                    ElseIf row(n) = 41 Then
                        g.DrawImage(bmpScientist, rectDest, rect0, GraphicsUnit.Pixel)
                    End If

                Next
                m += 1
            Loop
            streamReader.Close()
        Catch ex As Exception
            MsgBox("ERROR: The file wasnt found!")
        End Try

        'draw the character in the top corner
        If level = 100 Then
            If lmDoor = True Then

                rectSource = New Rectangle(0, 160, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(0, 160, tilesize, tilesize)
                rectDest = New Rectangle(0, 160, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 0
                cury = 160

            Else
                rectSource = New Rectangle(448, 160, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(448, 160, tilesize, tilesize)
                rectDest = New Rectangle(448, 160, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 448
                cury = 160
            End If
        ElseIf level = 101 Then
            If lmDoor = True Then
                rectSource = New Rectangle(0, cury, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(0, cury, tilesize, tilesize)
                rectDest = New Rectangle(0, cury, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 0
            Else
                rectSource = New Rectangle(448, 160, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(448, 160, tilesize, tilesize)
                rectDest = New Rectangle(448, 160, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 448
                cury = 160

            End If
        ElseIf level = 102 Then
            If lmDoor = False Then

                rectSource = New Rectangle(32, 0, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(32, 0, tilesize, tilesize)
                rectDest = New Rectangle(32, 0, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 32
                cury = 0
            Else

                rectSource = New Rectangle(0, 160, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(0, 160, tilesize, tilesize)
                rectDest = New Rectangle(0, 160, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 0
                cury = 160
            End If
        ElseIf level = 102.5 Then


            rectSource = New Rectangle(32, 448, tilesize, tilesize)
            firstSource = rectSource
            startRect = New Rectangle(32, 448, tilesize, tilesize)
            rectDest = New Rectangle(32, 448, tilesize, tilesize)
            gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
            g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
            curx = 32
            cury = 448


        ElseIf level = 200 Then
            If lmDoor = True Then
                rectSource = New Rectangle(32, 0, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(32, 0, tilesize, tilesize)
                rectDest = New Rectangle(32, 0, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 32
                cury = 0
            ElseIf lmDoor = False Then
                rectSource = New Rectangle(448, cury, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(448, cury, tilesize, tilesize)
                rectDest = New Rectangle(448, cury, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 448
            End If
        ElseIf level = 201 Then
            If lmDoor = True And challengeExit = False Then
                rectSource = New Rectangle(0, cury, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(0, cury, tilesize, tilesize)
                rectDest = New Rectangle(0, cury, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 0
            ElseIf lmDoor = False And challengeExit = False Then
                rectSource = New Rectangle(448, cury, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(448, cury, tilesize, tilesize)
                rectDest = New Rectangle(448, cury, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 448
            ElseIf challengeExit Then
                challengeExit = False
                rectSource = New Rectangle(curx, 0, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(curx, 0, tilesize, tilesize)
                rectDest = New Rectangle(curx, 0, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                cury = 0
            End If
        ElseIf level = 201.5 Then
            rectSource = New Rectangle(curx, 448, tilesize, tilesize)
            firstSource = rectSource
            startRect = New Rectangle(curx, 448, tilesize, tilesize)
            rectDest = New Rectangle(curx, 448, tilesize, tilesize)
            gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
            g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
            cury = 448
        ElseIf level = 202 Then
            If lmDoor = True Then
                rectSource = New Rectangle(0, cury, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(0, cury, tilesize, tilesize)
                rectDest = New Rectangle(0, cury, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 0
                'THE BELOW BLOCK OF CODE IS UNUSED SO FAR (TO BE MODIFIED AND USED LATER)
            ElseIf lmDoor = False Then
                rectSource = New Rectangle(0, cury, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(0, cury, tilesize, tilesize)
                rectDest = New Rectangle(0, cury, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 0
            End If
            'Ckearing path!
        ElseIf level = 300 Then
            If lmDoor = False Then
                rectSource = New Rectangle(0, 352, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(0, 352, tilesize, tilesize)
                rectDest = New Rectangle(0, 352, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 0
                cury = 352


            Else
                rectSource = New Rectangle(384, 0, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(384, 0, tilesize, tilesize)
                rectDest = New Rectangle(384, 0, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 384
                cury = 0
            End If
        ElseIf level = 301 Then
            rectSource = New Rectangle(416, 352, tilesize, tilesize)
            firstSource = rectSource
            startRect = New Rectangle(416, 352, tilesize, tilesize)
            rectDest = New Rectangle(416, 352, tilesize, tilesize)
            gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
            g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
            curx = 416
            cury = 352
            If frmStartPage.ScientistFirstEncounter = True Then
                MsgBox("Something feels off... but you cant quite put your finger on it...")
            End If
        ElseIf level = 301.5 Then
            If frmStartPage.RemovedLog = False Then
                rectSource = New Rectangle(64, 96, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(64, 96, tilesize, tilesize)
                rectDest = New Rectangle(64, 96, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 64
                cury = 96

            Else
                rectSource = New Rectangle(416, 352, tilesize, tilesize)
                firstSource = rectSource
                startRect = New Rectangle(416, 352, tilesize, tilesize)
                rectDest = New Rectangle(416, 352, tilesize, tilesize)
                gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
                g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
                curx = 416
                cury = 352
                If frmStartPage.ScientistFirstEncounter = True Then
                    MsgBox("Something feels off... but you cant quite put your finger on it...")
                End If
            End If

        ElseIf level = 400 Then
            rectSource = New Rectangle(32, 160, tilesize, tilesize)
            firstSource = rectSource
            startRect = New Rectangle(32, 160, tilesize, tilesize)
            rectDest = New Rectangle(32, 160, tilesize, tilesize)
            gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
            g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
            curx = 32
            cury = 160
        ElseIf level = 401 Then
            rectSource = New Rectangle(32, 416, tilesize, tilesize)
            firstSource = rectSource
            startRect = New Rectangle(32, 416, tilesize, tilesize)
            rectDest = New Rectangle(32, 416, tilesize, tilesize)
            gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
            g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
            curx = 32
            cury = 416
        ElseIf level = 401.5 Then
            rectSource = New Rectangle(32, 416, tilesize, tilesize)
            firstSource = rectSource
            startRect = New Rectangle(32, 416, tilesize, tilesize)
            rectDest = New Rectangle(32, 416, tilesize, tilesize)
            gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
            g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
            curx = 32
            cury = 416
        ElseIf level = 402 Then
            rectSource = New Rectangle(32, 128, tilesize, tilesize)
            firstSource = rectSource
            startRect = New Rectangle(32, 128, tilesize, tilesize)
            rectDest = New Rectangle(32, 128, tilesize, tilesize)
            gmini.DrawImage(backbuffer, startRect, rectDest, GraphicsUnit.Pixel)
            g.DrawImage(bmpCharacter, startRect, rectDest, GraphicsUnit.Pixel)
            curx = 0
            cury = 128


        End If
    End Sub

    Private Sub PerpetuaMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If LeftTunnelPath1.FollowThePath = True Then
            level = 100
            MainGame(level)
        ElseIf LeftTunnelPath1.TheLakePath = True Then
            level = 200
            MainGame(level)
        ElseIf LeftTunnelPath1.TheClearingPath = True Then
            level = 300
            MainGame(level)
        ElseIf LaboratoryPathInterlude1.labPath = True Then
            level = 400
            MainGame(level)
        End If


    End Sub

    Private Sub PerpetuaMain_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        'depending on which arrow key is pressed, choose a direction (actual value will be a number from 0 to 3)
        'also check the destination tile to make sure it is grass, not water
        Dim gback As Graphics = Graphics.FromImage(backbuffer)
        Dim gmini As Graphics = Graphics.FromImage(miniBuffer)
        Dim destTile As Integer



        If tmrMove.Enabled = False Then
            lastDirection = direction
            If e.KeyCode = Keys.Right And (0 <= (curx + tilesize) \ tilesize) And ((curx + tilesize) \ tilesize <= 14) And (0 <= cury \ tilesize) And (cury \ tilesize <= 14) Then
                direction = dir.right
                destTile = mapLoader((curx + tilesize) \ tilesize, cury \ tilesize)
                gback.DrawImage(firstTile, firstSource, rect0, GraphicsUnit.Pixel)
                If level = 201.5 And destTile <> 3 Then
                    treeRectSource = New Rectangle(curx + 32, 224, tilesize, tilesize)
                    gback.DrawImage(bmpTree, treeRectSource, rect0, GraphicsUnit.Pixel)
                    gback.DrawImage(bmpGrass, oldTreeRectSource, rect0, GraphicsUnit.Pixel)
                    mapLoader((curx + tilesize) \ tilesize, 7) = 3
                    mapLoader(curx \ tilesize, 7) = 0
                    oldTreeRectSource = treeRectSource
                End If
            ElseIf e.KeyCode = Keys.Left And (0 <= (curx - tilesize) \ tilesize) And ((curx - tilesize) \ tilesize <= 14) And (0 <= cury \ tilesize) And (cury \ tilesize <= 14) Then
                direction = dir.left
                destTile = mapLoader((curx - tilesize) \ tilesize, cury \ tilesize)
                gback.DrawImage(firstTile, firstSource, rect0, GraphicsUnit.Pixel)
                If level = 201.5 And destTile <> 3 Then
                    treeRectSource = New Rectangle(curx - 32, 224, tilesize, tilesize)
                    gback.DrawImage(bmpTree, treeRectSource, rect0, GraphicsUnit.Pixel)
                    gback.DrawImage(bmpGrass, oldTreeRectSource, rect0, GraphicsUnit.Pixel)
                    mapLoader((curx - tilesize) \ tilesize, 7) = 3
                    mapLoader(curx \ tilesize, 7) = 0
                    oldTreeRectSource = treeRectSource
                End If
            ElseIf e.KeyCode = Keys.Down And (0 <= curx \ tilesize) And (curx \ tilesize <= 14) And (0 <= (cury + tilesize) \ tilesize) And ((cury + tilesize) \ tilesize <= 14) Then
                direction = dir.down
                destTile = mapLoader(curx \ tilesize, (cury + tilesize) \ tilesize)
                gback.DrawImage(firstTile, firstSource, rect0, GraphicsUnit.Pixel)
            ElseIf e.KeyCode = Keys.Up And (0 <= curx \ tilesize) And (curx \ tilesize <= 14) And (0 <= (cury - tilesize) \ tilesize) And (cury - tilesize) \ tilesize <= 14 Then
                direction = dir.up
                destTile = mapLoader(curx \ tilesize, (cury - tilesize) \ tilesize)
                gback.DrawImage(firstTile, firstSource, rect0, GraphicsUnit.Pixel)
            Else
                destTile = -1
            End If

            'if the destination tile is grass, set variables and turn on timer to move character
            If destTile = 0 Or destTile = 2 Or destTile = 4 Or destTile = 6 Or destTile = 20 Or destTile = 21 Or destTile = 24 Then
                If destTile = 20 And frmStartPage.Rock = False Then
                    MsgBox("You collected a rock!")
                    frmStartPage.Rock = True
                ElseIf destTile = 21 And frmStartPage.Log = False Then
                    MsgBox("You collected a log")
                    frmStartPage.Log = True
                    'MAP CHANGE TO ALLOW HOLE TO BE VISIBLE UNDER LOG!!!!
                ElseIf destTile = 23 And frmStartPage.Pickaxe = False Then
                    MessageBox.Show("You collected a Pickaxe!")
                    frmStartPage.Pickaxe = True
                ElseIf destTile = 24 And frmStartPage.Axe = False Then
                    MsgBox("You collected an Axe!")
                    frmStartPage.Axe = True

                End If
                moves = 0           'moves will choose which frame of the spritemap to draw from
                smallMove = 10      'first step taken will be 10 pixels over
                tmrMove.Enabled = True
            Else
                'Depending on what item you have you will receive diffrent outcomes


                If frmStartPage.selectedItem = "Log" And destTile = 1 Then
                    MsgBox("You could use the log on the water to get across... ")

                End If





                'READ MEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE:
                '
                '
                'This noise plays whenever you press any button whatsoever (including the inventory button. Please fix it - Rumi
                '
                '+		$exception	{"Object reference not set to an instance of an object."}	System.NullReferenceException

                '
                '
                'My.Computer.Audio.Play(Application.StartupPath & "\bumpSound.wav")
            End If
        End If
    End Sub

    Private Sub PerpetuaMain_Paint(sender As Object, e As PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics
        g = e.Graphics
        g.DrawImage(backbuffer, 0, 0, backbuffer.Width, backbuffer.Height)
    End Sub

    Private Sub PerpetuaMain_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MyBase.KeyPress
        If Asc(e.KeyChar) = 105 Or Asc(e.KeyChar) = 73 Then
            frmInventory.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub tmrMove_Tick(sender As Object, e As EventArgs) Handles tmrMove.Tick
        Dim gback As Graphics
        Dim gmini As Graphics
        gback = Graphics.FromImage(backbuffer)
        gmini = Graphics.FromImage(miniBuffer)
        gback.DrawImage(miniBuffer, rectSource, rect0, GraphicsUnit.Pixel)      'draw into the background from the minibuffer (Heal.  There is now no sprite on the background.)

        'adjust current x or y coordinates depending on direction
        If direction = dir.right Then
            curx = curx + smallMove
        ElseIf direction = dir.left Then
            curx = curx - smallMove
        ElseIf direction = dir.down Then
            cury = cury + smallMove
        ElseIf direction = dir.up Then
            cury = cury - smallMove
        End If
        rectSource = New Rectangle(curx, cury, tilesize, tilesize)              'select new position on background.  This is where you plan to draw your sprite.
        gmini.DrawImage(backbuffer, rect0, rectSource, GraphicsUnit.Pixel)      'draw from new pos on background into minibuffer (preserve it so you can fix it later)
        rectDest = New Rectangle(moves * tilesize, direction * tilesize, tilesize, tilesize) 'select the correct frame from the spritemap
        gback.DrawImage(bmpCharacter, rectSource, rectDest, GraphicsUnit.Pixel)      'draw sprite onto background
        Me.Invalidate()
        moves += 1      'so you will select from the next frame of the spritemap
        smallMove = 11  'boost to 11 because 32 / 3 does not go evenly.  So moves are 10 + 11 + 11.  (If my spritemap had 4 frames, I could have done 4 moves of 8 pixels)
        'after 3 frames, you are done
        If moves = 3 Then
            tmrMove.Enabled = False
        End If
        If level = 100 And direction = dir.left And (rectSource = New Rectangle(0, 160, 32, 32) Or rectSource = New Rectangle(0, 192, 32, 32)) Then
            Me.Close()
            LeftTunnelPath1.Show()
        ElseIf frmStartPage.WolfFightCompleted = False And level = 100 And direction = dir.right And (rectSource = New Rectangle(288, 160, 32, 32) Or rectSource = New Rectangle(288, 192, 32, 32)) Then
            'Encounter1 is here
            'Encounter 1 = wolf encounter
            frmStartPage.encounterNumber = 1
            frmStartPage.WolfFightCompleted = True
            EncounterMain.Show()
            Me.Hide()

            Me.Hide()
            MsgBox("A wolf aproches you from the woods!")

        ElseIf level = 100 And direction = dir.right And (rectSource = New Rectangle(448, 160, 32, 32) Or rectSource = New Rectangle(448, 192, 32, 32)) Then
            lmDoor = True
            level = 101
            MainGame(101)

        ElseIf level = 101 And direction = dir.left And (rectSource = New Rectangle(0, 160, 32, 32) Or rectSource = New Rectangle(0, 192, 32, 32)) Then
            lmDoor = False
            level = 100
            MainGame(100)
        ElseIf level = 101 And direction = dir.right And (rectSource = New Rectangle(448, 160, 32, 32) Or rectSource = New Rectangle(448, 192, 32, 32)) Then
            lmDoor = True
            level = 102
            MainGame(102)
        ElseIf frmStartPage.BearFightCompleted = False And level = 101 And direction = dir.right And (rectSource = New Rectangle(224, 416, 32, 32) Or rectSource = New Rectangle(224, 384, 32, 32)) Then
            'Encounter 2 is here
            'Encounter 2 = Bear Encounter
            frmStartPage.encounterNumber = 2
            frmStartPage.BearFightCompleted = True
            EncounterMain.Show()
            Me.Hide()
            MsgBox("A bear aproches you from the woods!")
        ElseIf level = 102 And direction = dir.left And (rectSource = New Rectangle(0, 160, 32, 32) Or rectSource = New Rectangle(0, 192, 32, 32)) Then
            lmDoor = False
            level = 101
            MainGame(101)
        ElseIf level = 102 And direction = dir.up And (rectSource = New Rectangle(32, 0, 32, 32)) Then
            'You can collect the axe in area 102.5

            level = 102.5
            MainGame(102.5)
        ElseIf level = 102.5 And direction = dir.down And rectSource = New Rectangle(32, 448, 32, 32) Then
            lmDoor = False
            level = 102
            MainGame(102)

        ElseIf level = 200 And direction = dir.up And (rectSource = New Rectangle(64, 0, 32, 32) Or rectSource = New Rectangle(32, 0, 32, 32)) Then
            Me.Close()
            LeftTunnelPath1.Show()
        ElseIf level = 200 And direction = dir.right And (rectSource = New Rectangle(448, 320, 32, 32) Or rectSource = New Rectangle(448, 352, 32, 32)) Then
            lmDoor = True
            level = 201
            MainGame(201)
        ElseIf level = 201 And direction = dir.left And (rectSource = New Rectangle(0, 320, 32, 32) Or rectSource = New Rectangle(0, 352, 32, 32)) Then
            lmDoor = False
            level = 200
            MainGame(200)
        ElseIf level = 201 And direction = dir.right And (rectSource = New Rectangle(448, 160, 32, 32) Or rectSource = New Rectangle(448, 192, 32, 32)) Then
            lmDoor = True
            level = 202
            MainGame(202)
        ElseIf level = 201 And direction = dir.up And (rectSource = New Rectangle(224, 0, 32, 32)) Then
            level = 201.5
            firstTile = bmpGrass
            MainGame(201.5)
        ElseIf level = 201 And (rectSource = New Rectangle(416, 160, 32, 32) Or rectSource = New Rectangle(416, 192, 32, 32)) And frmStartPage.selectedItem = "Pickaxe" Then
            boulderChallengeCompleted = True
            level = 201
            MainGame(201)
        ElseIf level = 201 And (rectSource = New Rectangle(416, 160, 32, 32) Or rectSource = New Rectangle(416, 192, 32, 32)) And frmStartPage.selectedItem <> "Pickaxe" Then
            MsgBox("No pickaxe")
        ElseIf level = 201.5 And direction = dir.down And (rectSource = New Rectangle(224, 448, 32, 32)) Then
            level = 201
            challengeExit = True
            firstTile = bmpGrass
            MainGame(201)
        ElseIf level = 202 And direction = dir.left And (rectSource = New Rectangle(0, 160, 32, 32) Or rectSource = New Rectangle(0, 192, 32, 32)) Then
            lmDoor = False
            level = 201
            MainGame(201)
        ElseIf level = 300 And direction = dir.up And (rectSource = New Rectangle(384, 0, 32, 32) Or rectSource = New Rectangle(416, 0, 32, 32)) Then
            Me.Close()
            LeftTunnelPath1.Show()

        ElseIf level = 300 And direction = dir.left And (rectSource = New Rectangle(0, 352, 32, 32) Or rectSource = New Rectangle(0, 384, 32, 32)) Then
            If frmStartPage.RemovedLog = True Then
                lmDoor = True
                level = 301.5
                MainGame(301.5)
            Else
                lmDoor = True
                level = 301
                MainGame(301)
            End If
        ElseIf level = 301 And direction = dir.right And (rectSource = New Rectangle(448, 352, 32, 32) Or rectSource = New Rectangle(448, 384, 32, 32)) Then
            lmDoor = False
            level = 300
            MainGame(300)
        ElseIf level = 301 And direction = dir.left And (rectSource = New Rectangle(64, 96, 32, 32)) Then

            level = 301.5
            MainGame(301.5)
            firstTile = bmpHole
            frmStartPage.RemovedLog = True
        ElseIf level = 301.5 And direction = dir.right And (rectSource = New Rectangle(448, 352, 32, 32) Or rectSource = New Rectangle(448, 384, 32, 32)) Then
            lmDoor = False
            firstTile = bmpDirt
            level = 300
            MainGame(300)
        ElseIf level = 301.5 And direction = dir.left And rectSource = New Rectangle(64, 96, 32, 32) Then

            If frmStartPage.selectedItem = "Pickaxe" Then

                'Checks if the player has a tool to open the hatch
                MsgBox("You're now able to open the metal grate thanks too your pickaxe!")
                'Industrial section starts after this
                LeftTunnelPath1.TheClearingPath = False
                LeftTunnelPath1.TheLakePath = False
                LeftTunnelPath1.FollowThePath = False
                LaboratoryPathInterlude1.Show()
                Me.Close()
            Else
                MsgBox("If you had a sharp tool you could open the metal hatch under your feet...")
            End If
        ElseIf level = 400 And direction = dir.right And (rectSource = New Rectangle(448, 416, 32, 32) Or rectSource = New Rectangle(448, 384, 32, 32)) Then
            If frmStartPage.ScientistFirstEncounter = False Then


                level = 401
                MainGame(401)
            Else
                'If you have already met up with the scientist this will happen:
                level = 401.5
                MainGame(401.5)

            End If
        ElseIf level = 401 And direction = dir.up And rectSource = New Rectangle(192, 352, 32, 32) Then
            MsgBox("Well... your not supposed to be here...")
            MsgBox("I see... you've somehow ended up in the wrong location...")
            MsgBox("I'll get you out of here but due too the rules I have to erase your memory... Sorry")
            MsgBox("You see a large flash and then you suddently lose control of your muscles...")

            'This here will reset the game but wont show the gameover screen...

            'Scientist First encounter completed after this point:
            frmStartPage.ScientistFirstEncounter = True

            frmStartPage.Rock = False
            frmStartPage.Log = False
            frmStartPage.Pickaxe = False
            frmStartPage.Axe = False
            frmStartPage.selectedItem = ""
            frmStartPage.RemovedLog = False
            frmStartPage.WolfFightCompleted = False
            frmStartPage.BearFightCompleted = False
            frmStartPage.encounterNumber = 0

            frmStartPage.Show()
            Me.Close()
        ElseIf level = 401.5 And direction = dir.up And rectSource = New Rectangle(192, 352, 32, 32) Then
            MsgBox("Your memories suddently come fluding back, you remember everything that happened.")
            MsgBox("The scientist is also missing...")
        ElseIf level = 401.5 And direction = dir.right And rectSource = New Rectangle(448, 128, 32, 32) Then
            level = 402
            MainGame(402)

        End If



    End Sub

End Class