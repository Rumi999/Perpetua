﻿Public Class HelpScreen
    Private Sub HelpScreen_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MyBase.KeyPress
        If Asc(e.KeyChar) = 27 Then
            Me.Close()
            frmStartPage.Show()

        End If
    End Sub


End Class