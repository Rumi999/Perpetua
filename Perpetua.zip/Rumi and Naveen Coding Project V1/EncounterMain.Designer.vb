﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EncounterMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.picEncounter = New System.Windows.Forms.PictureBox()
        Me.tmrConstantCheck = New System.Windows.Forms.Timer(Me.components)
        Me.lblUseItem = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.lblAlternate = New System.Windows.Forms.Label()
        Me.lblFlee = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        CType(Me.picEncounter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picEncounter
        '
        Me.picEncounter.Location = New System.Drawing.Point(352, 224)
        Me.picEncounter.Name = "picEncounter"
        Me.picEncounter.Size = New System.Drawing.Size(32, 32)
        Me.picEncounter.TabIndex = 0
        Me.picEncounter.TabStop = False
        '
        'tmrConstantCheck
        '
        Me.tmrConstantCheck.Enabled = True
        '
        'lblUseItem
        '
        Me.lblUseItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(39, Byte), Integer))
        Me.lblUseItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUseItem.Location = New System.Drawing.Point(96, 352)
        Me.lblUseItem.Name = "lblUseItem"
        Me.lblUseItem.Size = New System.Drawing.Size(125, 25)
        Me.lblUseItem.TabIndex = 6
        Me.lblUseItem.Text = "ATTACK"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.attackButton
        Me.PictureBox1.Location = New System.Drawing.Point(96, 352)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(125, 25)
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.otherButton
        Me.PictureBox2.Location = New System.Drawing.Point(259, 352)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(125, 25)
        Me.PictureBox2.TabIndex = 8
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources.fleeButton
        Me.PictureBox3.Location = New System.Drawing.Point(178, 391)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(126, 25)
        Me.PictureBox3.TabIndex = 9
        Me.PictureBox3.TabStop = False
        '
        'lblAlternate
        '
        Me.lblAlternate.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(74, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.lblAlternate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAlternate.Location = New System.Drawing.Point(259, 352)
        Me.lblAlternate.Name = "lblAlternate"
        Me.lblAlternate.Size = New System.Drawing.Size(125, 25)
        Me.lblAlternate.TabIndex = 10
        Me.lblAlternate.Text = "ALTERNATE"
        '
        'lblFlee
        '
        Me.lblFlee.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblFlee.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFlee.Location = New System.Drawing.Point(178, 391)
        Me.lblFlee.Name = "lblFlee"
        Me.lblFlee.Size = New System.Drawing.Size(126, 25)
        Me.lblFlee.TabIndex = 11
        Me.lblFlee.Text = "FLEE"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(68, 192)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(100, 23)
        Me.ProgressBar1.TabIndex = 12
        Me.ProgressBar1.Value = 100
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(320, 192)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(100, 23)
        Me.ProgressBar2.TabIndex = 13
        Me.ProgressBar2.Value = 100
        '
        'EncounterMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(480, 479)
        Me.Controls.Add(Me.ProgressBar2)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.lblFlee)
        Me.Controls.Add(Me.lblAlternate)
        Me.Controls.Add(Me.lblUseItem)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.picEncounter)
        Me.MaximumSize = New System.Drawing.Size(496, 518)
        Me.MinimumSize = New System.Drawing.Size(496, 518)
        Me.Name = "EncounterMain"
        Me.Text = "ENCOUNTER"
        CType(Me.picEncounter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents picEncounter As PictureBox
    Friend WithEvents tmrConstantCheck As Timer
    Friend WithEvents lblUseItem As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents lblAlternate As Label
    Friend WithEvents lblFlee As Label
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents ProgressBar2 As ProgressBar
End Class
