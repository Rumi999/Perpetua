﻿Public Class frmStartPage
    'Saves selected items:
    Public selectedItem As String

    'Items booleans:
    Public Rock As Boolean = False
    Public Pickaxe As Boolean = False
    Public Log As Boolean = False
    Public Axe As Boolean = False

    'scenario changers:
    Public RemovedLog As Boolean = False
    Public ScientistFirstEncounter As Boolean = False
    Public WolfFightCompleted As Boolean = False
    Public BearFightCompleted As Boolean = False

    'Encoutner Number
    Public encounterNumber As Integer

    Private Sub btnStart_Click(sender As Object, e As EventArgs)
        Me.Hide()
        ChoseAtunnel.Show()
    End Sub

    Private Sub frmStartPage_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MyBase.KeyPress
        If Asc(e.KeyChar) = 32 Then
            Me.Hide()
            ChoseAtunnel.Show()

        ElseIf Asc(e.KeyChar) = 104 Or Asc(e.KeyChar) = 72 Then

            HelpScreen.Show()
            Me.Hide()

        End If
    End Sub

    Private Sub frmStartPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'EncounterMain.Show()
        'EncounterMain.Hide()
    End Sub
End Class