﻿Public Class EncounterMain
    Dim Stamina As Integer = 10
    Dim PlayerHealth As Integer = 100
    Dim EnemyHealth As Integer
    Private Sub EncounterMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If frmStartPage.encounterNumber = 1 Then
            picEncounter.Image = My.Resources.grassTexture_Wolf
            Me.BackgroundImage = My.Resources.GrassEncounterScreen
            lblAlternate.Text = "Pet the wolf"
            EnemyHealth = 75
        ElseIf frmStartPage.encounterNumber = 2 Then
            picEncounter.Image = My.Resources.Bear
            Me.BackgroundImage = My.Resources.GrassEncounterScreen
            lblAlternate.Text = "Ride the bear"
            EnemyHealth = 100
        ElseIf frmStartPage.encounterNumber = 3 Then
            picEncounter.Image = My.Resources.Shark
            Me.BackgroundImage = My.Resources.WaterEncounterrScreen
            lblAlternate.Text = "Ride the shark"
            EnemyHealth = 125


        End If



    End Sub

    Private Sub tmrConstantCheck_Tick(sender As Object, e As EventArgs) Handles tmrConstantCheck.Tick
        'This timer will be constantly checking if the player dies




        If PlayerHealth = 0 Then
            tmrConstantCheck.Enabled = False

            MsgBox("Youre dead :)")
            PlayerHealth = 3
            'There should be a death form which is opened here :)
            GameOver.Show()
            Me.Close()
        End If

    End Sub

    Private Sub EnemyDamage()
        'where enemey health is managed
        If frmStartPage.selectedItem = "Log" Then
            EnemyHealth = EnemyHealth - 20
        ElseIf frmStartPage.selectedItem = "Pickaxe" Then
            EnemyHealth = EnemyHealth - 35
        End If

        'IMAGES
        If EnemyHealth <= 0 Then
            MsgBox("You defeated the enemy!")
            PerpetuaMain.Show()
            Me.Close()
        End If

        If EnemyHealth > 0 Then
            Call EnemyAttack()
            'USE IMAGE TO REPRESENT HEALTH
            ProgressBar2.Value = EnemyHealth
        End If
    End Sub
    Private Sub EnemyAttack()
        'Wolf 
        If frmStartPage.encounterNumber = 1 Then
            MsgBox("You were attacked by the wolf!")
            PlayerHealth = PlayerHealth - 10
        ElseIf frmStartPage.encounterNumber = 2 Then
            MsgBox("You were attacked by the bear")
            PlayerHealth = PlayerHealth - 25
        ElseIf frmStartPage.encounterNumber = 3 Then
            MsgBox("You were attacked by the shark")
        ElseIf frmStartPage.encounterNumber = 4 Then

        End If

        'Player looses health


        'THIS IS UNECESARY IF WE HAVE IMAGES - Rumi
        ProgressBar1.Value = PlayerHealth
    End Sub



    Private Sub lblUseItem_Click_1(sender As Object, e As EventArgs) Handles lblUseItem.Click
        If Stamina = 0 Then
            MsgBox("Youre too weak to throw an attack")
            'Checks what the current encounter is 
            'Encounter 1 = wolf encounter
            'Encounter 2 = bear encounter
            'Encounter 3 = Shark
        ElseIf frmStartPage.encounterNumber = 1 Then
            If frmStartPage.selectedItem = "Rock" Then
                MsgBox("You threw at rock at the wolf, it didnt do any damage.")
                Stamina = Stamina - 1
            ElseIf frmStartPage.selectedItem = "Log" Then
                MsgBox("You threw a log at the wolf, it lost some hp.")
                'Using the heavy log demishes your stamina alot more than using the pickaxe
                Stamina = Stamina - 5
                Call EnemyDamage()
            ElseIf frmStartPage.selectedItem = "Pickaxe" Then
                MsgBox("You charged the wolf pickaxe in hand and stabed it. The wolf lost some of his hp.")
                Stamina = Stamina - 2
                Call EnemyDamage()
            Else
                MsgBox("You atempted to attack the wolf but you had no items to attack it with.")
                Call EnemyAttack()
            End If

        ElseIf frmStartPage.encounterNumber = 2 Then
            'BEAR ENCOUTNER
            If frmStartPage.selectedItem = "Rock" Then
                MsgBox("You threw at rock at the bear, it didnt do any damage.")
                Stamina = Stamina - 1
            ElseIf frmStartPage.selectedItem = "Log" Then
                MsgBox("You threw a log at the bear, it lost some hp.")
                'Using the heavy log demishes your stamina alot more than using the pickaxe
                Stamina = Stamina - 5
                Call EnemyDamage()
            ElseIf frmStartPage.selectedItem = "Pickaxe" Then
                MsgBox("You charged the bear pickaxe in hand and scraped it. The bear lost some of his hp.")
                Stamina = Stamina - 2
                Call EnemyDamage()
            Else
                MsgBox("You atempted to attack the bear but you had no items to attack it with.")
                Call EnemyAttack()
            End If

        ElseIf frmStartPage.encounterNumber = 3 Then
            'BEAR ENCOUTNER
            If frmStartPage.selectedItem = "Rock" Then
                MsgBox("You threw at rock at the shark, it didnt do any damage.")
                Stamina = Stamina - 1
            ElseIf frmStartPage.selectedItem = "Log" Then
                MsgBox("You threw a log at the shark, it lost some hp.")
                'Using the heavy log demishes your stamina alot more than using the pickaxe
                Stamina = Stamina - 5
                Call EnemyDamage()
            ElseIf frmStartPage.selectedItem = "Pickaxe" Then
                MsgBox("You swam towards the shark pickaxe in hand and scraped it. The shark lost some of his hp.")
                Stamina = Stamina - 2
                Call EnemyDamage()
            Else
                MsgBox("You atempted to attack the shark but you had no items to attack it with.")
                Call EnemyAttack()
            End If

        End If
    End Sub

    Private Sub lblAlternate_Click_1(sender As Object, e As EventArgs) Handles lblAlternate.Click
        If frmStartPage.encounterNumber = 1 Then
            'You tried to pet the wolf
            MsgBox("You tried to pet the wolf and it bit your entire arm off!!!")
            GameOver.Show()
            Me.Close()
        ElseIf frmStartPage.encounterNumber = 2 Then
            'you tried to ride the bear
            MsgBox("You tried to ride the bear and he ended up killing you !")
            GameOver.Show()
            Me.Close()
        End If
    End Sub

    Private Sub lblFlee_Click(sender As Object, e As EventArgs) Handles lblFlee.Click
        'Running away from battle is all based on rng. if you get the number 7 you escape if you dont, you get attacked and lose health.
        Dim ChanceOfEscape As Integer
        ChanceOfEscape = (Int(Rnd() * 5))

        If ChanceOfEscape = 4 Then
            MsgBox("You were able to escape the battle")
            PerpetuaMain.Show()
            Me.Close()

        Else
            MsgBox("You weren't able to escape the battle")
            Call EnemyAttack()
        End If
    End Sub



    'This is where all the "fixed encounters will take place"

    'Work in progressss



End Class