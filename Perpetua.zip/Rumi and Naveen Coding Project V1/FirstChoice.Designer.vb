﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ChoseAtunnel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblLeftTunnel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblLeftTunnel
        '
        Me.lblLeftTunnel.BackColor = System.Drawing.Color.Transparent
        Me.lblLeftTunnel.Location = New System.Drawing.Point(3, 220)
        Me.lblLeftTunnel.Name = "lblLeftTunnel"
        Me.lblLeftTunnel.Size = New System.Drawing.Size(141, 39)
        Me.lblLeftTunnel.TabIndex = 0
        '
        'ChoseAtunnel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.BackgroundImage = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources._2__Left_Tunnel__Right_Tunnel
        Me.ClientSize = New System.Drawing.Size(319, 318)
        Me.Controls.Add(Me.lblLeftTunnel)
        Me.MaximumSize = New System.Drawing.Size(335, 357)
        Me.MinimumSize = New System.Drawing.Size(335, 357)
        Me.Name = "ChoseAtunnel"
        Me.Text = "   "
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblLeftTunnel As Label
End Class
