﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class LeftTunnelPath1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblTowardsTheLake = New System.Windows.Forms.Label()
        Me.lblFollowThePath = New System.Windows.Forms.Label()
        Me.lblHeadToTheClearing = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblTowardsTheLake
        '
        Me.lblTowardsTheLake.BackColor = System.Drawing.Color.Transparent
        Me.lblTowardsTheLake.Location = New System.Drawing.Point(12, 273)
        Me.lblTowardsTheLake.Name = "lblTowardsTheLake"
        Me.lblTowardsTheLake.Size = New System.Drawing.Size(133, 31)
        Me.lblTowardsTheLake.TabIndex = 3
        '
        'lblFollowThePath
        '
        Me.lblFollowThePath.BackColor = System.Drawing.Color.Transparent
        Me.lblFollowThePath.Location = New System.Drawing.Point(12, 223)
        Me.lblFollowThePath.Name = "lblFollowThePath"
        Me.lblFollowThePath.Size = New System.Drawing.Size(133, 35)
        Me.lblFollowThePath.TabIndex = 4
        '
        'lblHeadToTheClearing
        '
        Me.lblHeadToTheClearing.BackColor = System.Drawing.Color.Transparent
        Me.lblHeadToTheClearing.Location = New System.Drawing.Point(12, 168)
        Me.lblHeadToTheClearing.Name = "lblHeadToTheClearing"
        Me.lblHeadToTheClearing.Size = New System.Drawing.Size(133, 38)
        Me.lblHeadToTheClearing.TabIndex = 5
        '
        'LeftTunnelPath1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Rumi_and_Naveen_Coding_Project_V1.My.Resources.Resources._1__Forest__Clearing__Lake
        Me.ClientSize = New System.Drawing.Size(321, 320)
        Me.Controls.Add(Me.lblHeadToTheClearing)
        Me.Controls.Add(Me.lblFollowThePath)
        Me.Controls.Add(Me.lblTowardsTheLake)
        Me.Name = "LeftTunnelPath1"
        Me.Text = "LeftTunnelPath1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblTowardsTheLake As Label
    Friend WithEvents lblFollowThePath As Label
    Friend WithEvents lblHeadToTheClearing As Label
End Class
