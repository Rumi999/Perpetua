﻿Public Class frmInventory

    Dim counter As Integer

    Private Sub frmInventory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        counter = 9

        'If the item is collected then this code overides the placeholder questionmark items with the found item
        If frmStartPage.Rock = True Then
            lstItems.Items.Add("Rock")
            counter = counter - 1
        End If
        If frmStartPage.Pickaxe = False Then
            lstItems.Items.Add("Pickaxe")
            counter = counter - 1
        End If
        If frmStartPage.Log = True Then
            lstItems.Items.Add("Log")
            counter = counter - 1
        End If

        If frmStartPage.Axe = True Then
            lstItems.Items.Add("Axe")
            counter = counter - 1
        End If


        For x = 0 To counter
            lstItems.Items.Add("?????")
        Next

    End Sub

    Private Sub btnSelectItem_Click(sender As Object, e As EventArgs) Handles btnSelectItem.Click
        'changes selected item?
        frmStartPage.selectedItem = lstItems.SelectedItem
        MsgBox("The " & frmStartPage.selectedItem & " has been selected.")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        PerpetuaMain.Show()
    End Sub

    Private Sub lstItems_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstItems.SelectedIndexChanged

    End Sub
End Class