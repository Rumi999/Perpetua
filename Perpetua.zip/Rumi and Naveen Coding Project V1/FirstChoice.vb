﻿Public Class ChoseAtunnel
    Private Sub lblLeftTunnel_Click(sender As Object, e As EventArgs) Handles lblLeftTunnel.Click
        Me.Close()
        LeftTunnelPath1.Show()
    End Sub


End Class